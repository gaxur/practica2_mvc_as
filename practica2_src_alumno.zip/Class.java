import java.awt.Graphics;
import java.awt.Graphics2D;
//otros import

public class Class {
	
	//Atributos
	// …
	
	public Class() {
		//…		
	}
	
	public void draw(Graphics g){
		//Dibuja la clase
		Graphics2D g2 = (Graphics2D)g;
		
		// …
		
	}
	
	//Otros metodos	
	// …
}
